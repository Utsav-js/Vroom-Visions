📦 Vroom Visions X - Instagram Export Guide

🔧 Included Tools:
- After Effects (.ffx preset + screenshot)
- Media Encoder Settings (.epr + screenshot)
- Topaz AI Tips (screenshot)

📁 How to Use:

1. After Effects:
   → Import FFX into your timeline.
   → Match your footage resolution (1080p or 4K).
   → Screenshot included for reference.

2. Media Encoder:
   → Drag your comp and apply .epr preset.
   → Maintain bitrate for Instagram quality.

3. Topaz AI:
   → Use recommended settings from included TXT.
   → Refer to screenshot for exact interface.

📌 Note: All files are organized inside respective folders.

🔗 Follow @vroomvisionsx on Instagram for more tips!
